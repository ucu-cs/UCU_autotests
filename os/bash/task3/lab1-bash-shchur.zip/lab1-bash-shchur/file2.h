#ifndef FILE2_HEADER
#define FILE2_HEADER

void function_from_file2();

#endif // FILE2_HEADER
