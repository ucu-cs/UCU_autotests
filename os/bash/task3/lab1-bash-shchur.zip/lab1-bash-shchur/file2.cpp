#include <iostream>

#include "file2.h"

void function_from_file2()
{
	std::cout << "Hello world from ~~~file~~~ 2!" << std::endl;
}
