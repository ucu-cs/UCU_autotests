#ifndef FILE1_HEADER  
#define FILE1_HEADER

struct X{ int a, b,c; };

void function_from_file1(struct X x);

#endif // FILE1_HEADER
