#!/bin/bash

shmakefile=shmakefile

max() {
  if [ "$1" -gt "$2" ]; then
      echo "$1"
  else
      echo "$2"
  fi
}

build() {
  local tgt="$1"
  local isTopTask="$2"
  local tgt_modification_time=0
  local tgt_number=0
  local phony_tgt=0
  tgt_number=$(get_tgt_number "$tgt" "${tgts[@]}")

  if [ "$tgt_number" == "No such target!" ]; then
    echo "Invalid tgt: $arg" >&2
    return 1
  fi

  if [ "$tgt" == "all" ] || [ "$tgt" == ".PHONY" ]; then
    phony_tgt=1
  fi

  phony_number=$(get_tgt_number ".PHONY" "${tgts[@]}")
  if [ "$phony_number" != "No such target!" ]; then
    local phony_list=()
    local cur_pivot="${tgt_dep_num[phony_number]}"
    local end_phony_list="${tgt_dep_num[phony_number+1]}"
    while [ "$cur_pivot" -lt "$end_phony_list" ]
    do
      phony_list+="${tgts_dependencies[cur_pivot]}"
      ((cur_pivot++))
    done
    temp=$(get_tgt_number "$tgt" "${phony_list[@]}")
    if [ "$temp" != "No such target!" ]; then
      # echo "Target is phony!"
      phony_tgt=1
    fi
  fi

  local latest_time_stamp=0
  local cur="${tgt_dep_num[tgt_number]}"
  local end="${tgt_dep_num[tgt_number+1]}"
  while [ "$cur" -lt "$end" ]; do
    dep="${tgts_dependencies[cur]}"
    ((cur++))
    dependency_number=$(get_tgt_number "$dep" "${tgts[@]}")
    if [ "$dependency_number" == "No such target!" ] && [ -e "$dep" ]; then
      modification_time=$(stat -c %Y "$dep")
      latest_time_stamp=$(max "$modification_time" "$latest_time_stamp")
    elif [ "$dependency_number" == "No such target!" ]; then
      echo "Not existing dependency! ${dep}" >&2
      return 1
    else
      build "$dep" 0
      if [ "$?" -eq 1 ]; then
        return 1 # propagating error
      fi
      if [ -e "$dep" ]; then
        modification_time=$(stat -c %Y "$dep")
        latest_time_stamp=$(max "$modification_time" "$latest_time_stamp")
      elif [ "$phony_tgt" -eq 1 ]; then
        true
      else
        echo "Dependency didn't create the component needed!" >&2
        return 1
      fi
    fi
  done

  if [ -e "$tgt" ]; then
    tgt_modification_time=$(stat -c %Y "$tgt")
  fi

  if [ ! -e "$tgt" ] || [ "$tgt_modification_time" -lt "$latest_time_stamp" ] || [ "$phony_tgt" -eq 1 ]; then
    execute_block "$tgt_number"
  elif [ "$isTopTask" -eq 1 ]; then
    echo "tgt is up to date already" >&1
  fi

  if [ ! -e "$tgt" ] && [ ! "$phony_tgt" -eq 1 ]; then
    echo "tgt code didn't create the component needed!" >&2
    return 1
  else
    return 0
  fi
}

clear_whitespaces() {
  local input="$1"
  input="${input%"${input##*[![:space:]]}"}" # removing trailing whitespaces
  input="${input#"${input##*[![:space:]]}"}" # removing leading whitespaces
  echo "$input"
  return 0
}

get_tgt_number() {
  local tgt_name=$1
  shift
  local tgt_list=("$@")
  local i=0
  for item in "${tgt_list[@]}"; do
    if [ "$item" == "$tgt_name" ]; then
      break
    else
      ((i++))
    fi
  done
  if [ $i == "${#tgt_list[@]}" ]; then
    echo "No such target!"
  else
    echo "$i"
  fi
}

execute_block() {
  local tgt_num=$1
  if [ "${tgts_code_start[tgt_num]}" == "" ]; then
    true
  else
    index="${tgts_code_start[tgt_num]}"
    while [ "$index" -le "${tgts_code_end[tgt_num]}" ]
    do
      command=$(clear_whitespaces "${lines[index-1]}")
      if [ ! "$command" == "" ]; then
        echo "$command"
        eval "$command"
      fi
      ((index++))
    done
  fi

}

# Parse arguments
# ----------------------------------------------------------
flag_f=
positional_args=()
while getopts "f:" opt; do
    case "$opt" in
        f)
            flag_f="$OPTARG"
            ;;
        \?)
            echo "Invalid option: -$OPTARG" >&2
            exit 1
            ;;
    esac
done

shift $((OPTIND-1))
positional_args+=("$@")

if [ -n "$flag_f" ]; then
    echo "Using shmakefile: $flag_f"
    shmakefile="$flag_f"
fi
# ----------------------------------------------------------

# Parse shmakefile
# ----------------------------------------------------------
lines=()
tgts=()
tgts_dependencies=()
current_tgt_number=-1
last_line_was_tgt=0
tgts_code_start=()
tgts_code_end=()
tgt_dep_num=()
tgt_dep_num+=0

while IFS= read -r line || [[ -n "$line" ]]; do
    lines+=("$line")
done < "$shmakefile"

line_number=1

for line in "${lines[@]}"; do
    if [[ "$line" =~ ^$'\t' ]]; then
      if [ "$last_line_was_tgt" -eq 1 ]; then
          tgts_code_start["$current_tgt_number"]="$line_number"
          last_line_was_tgt=0
      elif [ ! "$current_tgt_number" -ge 0 ]; then
          echo "Shmakefile format error!" >&2
      fi
    elif [[ "$line" == *:* ]]; then
      tgt=($(echo "$line" | awk -F':' '{print $1}'| tr -s ' '))
      tgt=$(clear_whitespaces "$tgt")

      tgt_deps=($(echo "$line" | awk -F':' '{print $2}'| tr -s ' '))
      IFS=' ' read -ra tgt_deps_list <<< "${tgt_deps[@]}"

      tgt_deps_cleaned=()
      i=0
      for dep in "${tgt_deps_list[@]}"; do
        trimmed_val="${dep// /}"
        trimmed_val=$(clear_whitespaces "$trimmed_val") # probably double-trimming...
        if [ -n "$trimmed_val" ]; then
          tgt_deps_cleaned[i]="$trimmed_val"
          ((i++))
        fi
      done

      ((current_tgt_number++))

      tgts+=("$tgt")
      if [ "${#tgt_deps_cleaned[@]}" -gt 0 ]; then
        tgts_dependencies+=("${tgt_deps_cleaned[@]}")
      fi
      new_value=$((tgt_dep_num[current_tgt_number] + ${#tgt_deps_cleaned[@]}))
      tgt_dep_num+=("$new_value")

      if [ "$current_tgt_number" -gt 0 ]; then
         tgts_code_end[$current_tgt_number - 1]=$((line_number-1))
         if [ "${tgts_code_start[$current_tgt_number - 1]}" == "" ]; then
             tgts_code_start[$current_tgt_number - 1]=$((line_number-1))
         fi
      fi
      last_line_was_tgt=1
    else
      true
    fi
    ((line_number++))
done

if [ "$current_tgt_number" -gt 0 ]; then
  tgts_code_end[$current_tgt_number]=$((line_number-1))
  if [ "${tgts_code_start[$current_tgt_number]}" == "" ]; then
      tgts_code_start[$current_tgt_number]=$((line_number-1))
  fi
else
  echo "Invalid shmakefile: no tgts found!" >&2
  exit
fi

# ----------------------------------------------------------
# Building necessary tgts
# ----------------------------------------------------------
if [ "${#positional_args[@]}" -gt 0 ]; then
  for arg in "${positional_args[@]}"; do
    arg=$(clear_whitespaces "$arg")
    build "$arg" 1
  done
else
  build "${tgts[0]}" 1
fi
# ----------------------------------------------------------
exit