#include <iostream>

#include "file1.h"

void function_from_file1(struct X x)
{
	std::cout << "Hello world from __file__ 1!" << std::endl;
}
